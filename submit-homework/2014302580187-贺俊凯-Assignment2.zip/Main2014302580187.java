import java.util.*;
import java.util.regex.*;
import org.jsoup.Jsoup;
import org.jsoup.select.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import java.io.*;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.text.DecimalFormat;

public class Main2014302580187 {
	
	public static void main(String args[]) throws IOException
	{
		getURL();
		getInfo();
	}
	
	public static void getURL () throws IOException
	{
		//��ȡҳ��
		String urlPath = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=TAN%20Chengyu";
		String filePath = ".\\test.html";
		URL urlName = new URL(urlPath);
		FileOutputStream file = new FileOutputStream(filePath);
		HttpRequest out = new HttpRequest(urlName,"GET");
		out.receive(file);
		file.close();
		
	}	
	
	public static void getInfo() throws IOException
	{
		//����html
		Document doc = Jsoup.parse(new File(".\\test.html"),"UTF-8","");
		Elements elements = doc.select("p");
		Elements name = doc.select("h1");
		//���������ʽɸѡ����͵绰
		Pattern a = Pattern.compile("Email:+\\s+.+@+\\d+.+\\w"); 
		Pattern b = Pattern.compile("[0-9]+\\s");
		Matcher phoneNum = b.matcher(elements.get(0).text());
		Matcher emailAddress = a.matcher(elements.get(0).text());
		//�����洢����ҳ����Ϣ
		String[] info = new String[5];
		//�洢��Ϣ
		info[0] = "������"+name.get(0).text();
		info[1] = elements.get(4).text();
		info[2] = "��飺"+elements.get(3).text();
		while(phoneNum.find())
		{
			info[3] = "�绰��";
			info[3] += phoneNum.group();	
		}
		while(emailAddress.find())
		{
		    info[4] = emailAddress.group();
		}
		//д��TXT
		FileWriter file = new FileWriter(".\\out.txt");
		for(int i=0;i<info.length;i++)
		{
			file.write(info[i]+"\r\n");
			
		}
		file.close();
		
	}


}
